package com.team.prosvita.entities;

public enum Role {
    USER, ADMIN
}
