package com.team.prosvita.entities;

public enum Status {
    ACTIVE, INACTIVE, BANNED
}
