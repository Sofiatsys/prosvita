package com.team.prosvita;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProsvitaApplicationTests {

	@Test
	void contextLoads() {
	}

}
